package pokemon;

/**
 *
 * @author SamuelDitchi
 */
public class Pokemon {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Bienvenue f1 = new Bienvenue(); 
        f1.setVisible(true);
        
       //J'affiche la fenetre de bienvenue
    }
    
}
